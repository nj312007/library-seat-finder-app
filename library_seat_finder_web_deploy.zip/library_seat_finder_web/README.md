# Library Seat Finder — Web Edition

A Flask web conversion of the supplied Tkinter Library Seat Finder.

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Run:
   ```bash
   python -m venv .venv
   # Windows:
   .venv\Scripts\activate
   # macOS/Linux:
   source .venv/bin/activate
   pip install -r requirements.txt
   python app.py
   ```
4. Open http://127.0.0.1:5000

## Deploy on Render
1. Create a GitHub repository and upload the contents of this folder.
2. In Render, choose **New + → Web Service** and connect that repository.
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app --workers 1 --threads 8 --timeout 120`
5. Deploy. Render will provide a public URL.

## Important notes
- The application keeps seat state in `seat_state.json` beside `app.py`.
- For reliable persistent data on a hosted service, configure a persistent disk mounted at the app directory, or replace JSON storage with a managed database. Some hosting plans use ephemeral filesystems.
- This is a prototype for demonstration. The original project describes an SRMIST floor layout; verify the real seat counts, library timings, and operating rules with the library before using it for actual seat allocation.
- The demo simulation overwrites current seat state. The Reset button clears all seats.
- Run one Gunicorn worker with this JSON-backed version; multiple workers or instances need shared database storage and concurrency controls.
