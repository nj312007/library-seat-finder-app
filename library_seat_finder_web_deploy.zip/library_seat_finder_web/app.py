import json, os, time, random
from datetime import datetime, timedelta
from flask import Flask, jsonify, request, render_template

app = Flask(__name__)
DATA_FILE = os.path.join(os.path.dirname(__file__), "seat_state.json")
HOUR = 3600

LAYOUT = [
    {"c":"G","name":"Ground Floor","zones":[
        {"c":"6T","name":"6-Seater Tables","kind":"t","per":6,"n":20},
        {"c":"4T","name":"4-Seater Tables","kind":"t","per":4,"n":25,"ch":1},
        {"c":"SG","name":"Single Seats","kind":"s","n":80}]},
    {"c":"1","name":"1st Floor","zones":[
        {"c":"6T","name":"6-Seater Tables","kind":"t","per":6,"n":15},
        {"c":"4T","name":"4-Seater Tables","kind":"t","per":4,"n":20},
        {"c":"2T","name":"2-Seater Tables","kind":"t","per":2,"n":20},
        {"c":"SG","name":"Single Seats","kind":"s","n":90,"ch":1}]},
    {"c":"2","name":"2nd Floor","zones":[
        {"c":"6T","name":"6-Seater Tables","kind":"t","per":6,"n":15},
        {"c":"EX","name":"Competitive Exam Hall","kind":"s","n":110,"q":1}]},
    {"c":"3","name":"3rd Floor (Staff Only)","staff":1,"zones":[]}
]

SEATS = {}
for floor in LAYOUT:
    for zone in floor["zones"]:
        per = zone["per"] if zone["kind"] == "t" else 1
        for table in range(1, zone["n"] + 1):
            for k in range(1, per + 1):
                sid = f'{floor["c"]}-{zone["c"]}-{table:02d}-S{k}'
                SEATS[sid] = {
                    "id": sid, "floor": floor["c"], "floor_name": floor["name"],
                    "zone": zone["c"], "zone_name": zone["name"],
                    "table": table, "seat_no": k, "capacity": per,
                    "charging": bool(zone.get("ch")), "quiet": bool(zone.get("q")),
                    "status": "a", "reg": None, "name": None,
                    "checkin": 0, "reserve_until": 0, "warned": False
                }
assert len(SEATS) == 800

def load_state():
    try:
        with open(DATA_FILE) as f:
            saved = json.load(f)
        for sid, values in saved.items():
            if sid in SEATS:
                SEATS[sid].update(values)
    except (OSError, ValueError, TypeError):
        pass

def save_state():
    data = {}
    for sid, s in SEATS.items():
        if s["status"] != "a":
            data[sid] = {k:s[k] for k in ("status","reg","name","checkin","reserve_until","warned")}
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w") as f:
        json.dump(data, f)
    os.replace(tmp, DATA_FILE)

def clean_expired():
    now = time.time()
    changed = False
    for s in SEATS.values():
        if s["status"] == "r" and now >= s["reserve_until"]:
            clear(s); changed = True
        elif s["status"] == "o" and now - s["checkin"] >= 4*HOUR:
            clear(s); changed = True
    if changed:
        save_state()

def clear(s):
    s.update(status="a", reg=None, name=None, checkin=0, reserve_until=0, warned=False)

def validate_member(reg, name):
    reg = (reg or "").strip().upper()
    name = (name or "").strip()
    if not reg:
        raise ValueError("Registration number cannot be empty.")
    if not reg.isascii() or not reg.isalnum():
        raise ValueError("Registration number: letters and digits only.")
    if not name:
        raise ValueError("Please enter your name.")
    return reg, name

def find_seats(count, charging, quiet, floor):
    clean_expired()
    groups = {}
    for s in SEATS.values():
        if floor != "any" and s["floor"] != floor:
            continue
        if charging and not s["charging"]:
            continue
        if s["status"] == "a":
            key = (s["floor"], s["zone"], s["table"])
            groups.setdefault(key, []).append(s)
    results = []
    for (fc, zc, table), free in groups.items():
        first = free[0]
        if len(free) < count:
            continue
        score = 100 - (first["capacity"] - count)*3
        if count > 1 and len(free) < first["capacity"]:
            score -= 15
        if quiet and first["quiet"]:
            score += 20
        elif not quiet and first["quiet"]:
            score -= 10
        if first["charging"] and not charging:
            score -= 2
        results.append({"floor":first["floor_name"],"floor_code":fc,
                        "zone":first["zone_name"],"table":table,
                        "charging":first["charging"],"quiet":first["quiet"],
                        "score":score,"seats":[x["id"] for x in free[:count]]})
    return sorted(results,key=lambda x:-x["score"])[:5]

@app.route("/")
def home():
    return render_template("index.html")

@app.get("/api/state")
def state():
    clean_expired()
    now = time.time()
    rows = list(SEATS.values())
    counts = {k:sum(s["status"] == k for s in rows) for k in ("a","o","r","u")}
    active = []
    for s in rows:
        if s["status"] in ("o","r"):
            left = (s["checkin"] + 4*HOUR - now) if s["status"] == "o" else (s["reserve_until"] - now)
            active.append({"id":s["id"],"name":s["name"],"status":s["status"],
                           "remaining":max(0,int(left)),"floor":s["floor_name"]})
    active.sort(key=lambda x:x["remaining"])
    return jsonify({"layout":LAYOUT[:3],"seats":rows,"counts":counts,
                    "active":active[:8],"server_time":now,
                    "is_open":datetime.now().hour >= 8})

@app.post("/api/action")
def action():
    clean_expired()
    data = request.get_json(silent=True) or {}
    sid, act = data.get("seat"), data.get("action")
    s = SEATS.get(sid)
    if not s:
        return jsonify(error="Seat not found."), 404
    try:
        if act in ("checkin","reserve"):
            if datetime.now().hour < 8:
                raise ValueError("Library is closed (open 8 AM to midnight).")
            reg,name = validate_member(data.get("reg"),data.get("name"))
            mine = next((x for x in SEATS.values() if x["reg"] == reg and x["status"] in ("o","r")),None)
            if mine and mine is not s:
                raise ValueError(f"{reg} already has seat {mine['id']}.")
            if act == "checkin":
                if s["status"] == "o": raise ValueError("This seat is already occupied.")
                if s["status"] == "u": raise ValueError("This seat is out of service.")
                if s["status"] == "r" and s["reg"] != reg: raise ValueError("Reserved for someone else.")
                s.update(status="o",reg=reg,name=name,checkin=time.time(),reserve_until=0,warned=False)
                message = f"Checked in at {sid}."
            else:
                if s["status"] != "a": raise ValueError("Seat is not available.")
                s.update(status="r",reg=reg,name=name,reserve_until=time.time()+900)
                message = f"Reserved {sid} for 15 minutes."
        elif act == "release":
            if s["status"] not in ("o","r"): raise ValueError("This seat is not occupied or reserved.")
            clear(s); message = f"Released {sid}."
        elif act == "toggle_service":
            if s["status"] not in ("a","u"): raise ValueError("Only free seats can be marked out of service.")
            s["status"] = "a" if s["status"] == "u" else "u"
            message = f"{sid} updated."
        else:
            raise ValueError("Unknown action.")
        save_state()
        return jsonify(message=message)
    except ValueError as e:
        return jsonify(error=str(e)), 400

@app.post("/api/find")
def find():
    data = request.get_json(silent=True) or {}
    try:
        count = max(1,min(6,int(data.get("count",1))))
    except (ValueError,TypeError):
        count = 1
    return jsonify(results=find_seats(count,bool(data.get("charging")),
                                      bool(data.get("quiet")),data.get("floor","any")))

@app.post("/api/demo")
def demo():
    for s in SEATS.values(): clear(s)
    sample = random.sample(list(SEATS.values()), int(800*random.uniform(.4,.7)))
    now = time.time()
    for i,s in enumerate(sample):
        s.update(status="o",reg=f"DEMO{10000+i}",name="Demo user",
                 checkin=now-random.random()*170*60)
    save_state()
    return jsonify(message="Demo busy-hour simulation loaded.")

@app.post("/api/reset")
def reset():
    for s in SEATS.values(): clear(s)
    save_state()
    return jsonify(message="All seats have been reset.")

load_state()

if __name__ == "__main__":
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT",5000)),debug=False)
